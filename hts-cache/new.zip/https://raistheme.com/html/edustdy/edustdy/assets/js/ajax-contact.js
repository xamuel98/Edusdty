<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
		<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<title>Coming soon&#8230; &#8211; RaisTheme</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link href='//fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="RaisTheme &raquo; Feed" href="https://raistheme.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="RaisTheme &raquo; Comments Feed" href="https://raistheme.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/raistheme.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.3.2"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://raistheme.com/wp-includes/css/dist/block-library/style.min.css?ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='https://raistheme.com/wp-includes/css/dist/block-library/theme.min.css?ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='email-subscribers-css'  href='https://raistheme.com/wp-content/plugins/email-subscribers/lite/public/css/email-subscribers-public.css' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-widgets-css'  href='https://raistheme.com/wp-content/plugins/raistheme-core/assets/css/raistheme-widgets.css?ver=342545915089' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-fonts-css'  href='//fonts.googleapis.com/css?family=Lora%3A400%2C400i%2C700%26display%3Dswap%7CHeebo%3A400%2C500%2C700%26display%3Dswap&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-style-css'  href='https://raistheme.com/wp-content/themes/raistheme/style.css?ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-block-style-css'  href='https://raistheme.com/wp-content/themes/raistheme/assets/css/blocks.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://raistheme.com/wp-content/plugins/raistheme-core/assets/css/bootstrap.min.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='https://raistheme.com/wp-content/plugins/raistheme-core/assets/css/font-awesome.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-flaticon-css'  href='https://raistheme.com/wp-content/themes/raistheme/assets/fonts/flaticon.css?ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='animate-style-css'  href='https://raistheme.com/wp-content/themes/raistheme/assets/css/animate.css?ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='edd-style-css'  href='https://raistheme.com/wp-content/themes/raistheme/assets/css/edd.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-theme-css'  href='https://raistheme.com/wp-content/themes/raistheme/assets/css/style.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-source-sans-css'  href='//fonts.googleapis.com/css?family=Montserrat%3A300%2C400%2C500%2C600%2C700&#038;ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-source-body-css'  href='//fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C700&#038;ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='raistheme-source-menu-css'  href='//fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C700&#038;ver=5.3.2' type='text/css' media='all' />
<script type='text/javascript' src='https://raistheme.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var es_data = {"messages":{"es_empty_email_notice":"Please enter email address","es_rate_limit_notice":"You need to wait for sometime before subscribing again","es_single_optin_success_message":"Successfully Subscribed.","es_email_exists_notice":"Email Address already exists!","es_unexpected_error_notice":"Oops.. Unexpected error occurred.","es_invalid_email_notice":"Invalid email address","es_try_later_notice":"Please try after some time"},"es_ajax_url":"https:\/\/raistheme.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/email-subscribers/lite/public/js/email-subscribers-public.js'></script>
<link rel='https://api.w.org/' href='https://raistheme.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://raistheme.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://raistheme.com/wp-includes/wlwmanifest.xml" /> 
<link rel='prev' title='Coming soon&#8230;..' href='https://raistheme.com/?elementor_library=coming-soon' />
<meta name="generator" content="WordPress 5.3.2" />
<link rel="canonical" href="https://raistheme.com/?elementor_library=coming-soon-2" />
<link rel='shortlink' href='https://raistheme.com/?p=987' />
<link rel="alternate" type="application/json+oembed" href="https://raistheme.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fraistheme.com%2F%3Felementor_library%3Dcoming-soon-2" />
<link rel="alternate" type="text/xml+oembed" href="https://raistheme.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fraistheme.com%2F%3Felementor_library%3Dcoming-soon-2&#038;format=xml" />
<meta name="generator" content="Easy Digital Downloads v2.9.19" />
                            <style type="text/css">
                    /*Logo*/
                    body.home.title-tagline-hidden.has-header-image .custom-logo-link img, 
                    body.home.title-tagline-hidden.has-header-video .custom-logo-link img, 
                    .header-wrapper .header-menu .site-branding img,
                     .site-branding img.custom-logo {
                        max-width: 180px;
                    }
                </style>
                        
            
        		<style>#wp-admin-bar-elementor-maintenance-on > a { background-color: #dc3232; }
			#wp-admin-bar-elementor-maintenance-on > .ab-item:before { content: "\f160"; top: 2px; }</style>
		      <link rel="icon" href="https://raistheme.com/wp-content/uploads/2019/11/cropped-raistheme-logo.png" sizes="32x32" />
<link rel="icon" href="https://raistheme.com/wp-content/uploads/2019/11/cropped-raistheme-logo.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://raistheme.com/wp-content/uploads/2019/11/cropped-raistheme-logo.png" />
<meta name="msapplication-TileImage" content="https://raistheme.com/wp-content/uploads/2019/11/cropped-raistheme-logo.png" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body data-rsssl=1 class="elementor_library-template elementor_library-template-elementor_canvas single single-elementor_library postid-987 wp-embed-responsive has-header-image has-sidebar colors-light elementor-default elementor-template-canvas elementor-page elementor-page-987 elementor-maintenance-mode">
			<div data-elementor-type="page" data-elementor-id="987" class="elementor elementor-987" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section class="elementor-element elementor-element-7261ef10 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="7261ef10" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-68f12e6d elementor-column elementor-col-100 elementor-top-column" data-id="68f12e6d" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-17651c91 elementor-widget elementor-widget-text-editor" data-id="17651c91" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>Hey Guys! We’re Coming Soon… Our website is under construction. We`ll be here soon with our new awesome site.</p><p>If you need any support? Feel free to contact us <a href="https://raistheme.com/support">here</a>.</p></div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
		<link rel='stylesheet' id='elementor-frontend-css'  href='https://raistheme.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=2.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-987-css'  href='https://raistheme.com/wp-content/uploads/elementor/css/post-987.css?ver=1585203886' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='https://raistheme.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='https://raistheme.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=2.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://raistheme.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='https://raistheme.com/wp-content/plugins/raistheme-core/assets/css/slick.min.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='https://raistheme.com/wp-content/uploads/elementor/css/global.css?ver=1582246251' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.3.2' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/raistheme.com\/wp-admin\/admin-ajax.php","position_in_cart":"","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"","redirect_to_checkout":"0","checkout_page":"https:\/\/raistheme.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.9.19'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var raisthemeScreenReaderText = {"quote":"<svg class=\"icon icon-quote-right\" aria-hidden=\"true\" role=\"img\"> <use href=\"#icon-quote-right\" xlink:href=\"#icon-quote-right\"><\/use> <\/svg>"};
/* ]]> */
</script>
<script type='text/javascript' src='https://raistheme.com/wp-content/themes/raistheme/assets/js/skip-link-focus-fix.js?ver=1.0.3'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/themes/raistheme/assets/js/global.js?ver=1.0.3'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/themes/raistheme/assets/js/jquery.scrollTo.js?ver=2.1.2'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/themes/raistheme/assets/js/jquery.countdown.min.js?ver=2.2.0'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/raistheme-core/assets/js/bootstrap.min.js?ver=1.0.3'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/themes/raistheme/assets/js/raistheme-theme.js?ver=1.0.3'></script>
<script type='text/javascript' src='https://raistheme.com/wp-includes/js/wp-embed.min.js?ver=5.3.2'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=2.9.2'></script>
<script type='text/javascript' src='https://raistheme.com/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.7.6'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.0'></script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=2.9.2'></script>
<script type='text/javascript'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","downloadImage":"Download image"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"2.9.2","urls":{"assets":"https:\/\/raistheme.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"general":{"elementor_global_image_lightbox":"yes","elementor_lightbox_enable_counter":"yes","elementor_lightbox_enable_fullscreen":"yes","elementor_lightbox_enable_zoom":"yes","elementor_lightbox_enable_share":"yes","elementor_lightbox_title_src":"title","elementor_lightbox_description_src":"description"},"editorPreferences":[]},"post":{"id":987,"title":"Coming soon&#8230; &#8211; RaisTheme","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='https://raistheme.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=2.9.2'></script>
	</body>
</html>
